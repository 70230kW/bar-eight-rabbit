
import React from 'react';
import { useScrollFadeIn } from '../hooks/useScrollFadeIn';

const InfoItem: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="flex flex-col sm:flex-row mb-6">
        <dt className="w-full sm:w-1/3 md:w-1/4 font-serif text-accent-primary text-lg">{title}</dt>
        <dd className="w-full sm:w-2/3 md:w-3/4 text-text-secondary leading-[1.7]">{children}</dd>
    </div>
);


const Info: React.FC = () => {
    const headerFade = useScrollFadeIn<HTMLHeadingElement>();
    const infoFade = useScrollFadeIn<HTMLDivElement>();
    const mapFade = useScrollFadeIn<HTMLDivElement>();

    return (
        <div className="bg-background-secondary text-text-primary pt-24 md:pt-32 pb-20 md:pb-32">
            <div className="container mx-auto px-4">
                <header className="text-center mb-20">
                    <h1 ref={headerFade.ref} className={`font-serif text-[clamp(2.8rem,5.5vw,4.5rem)] text-accent-primary ${headerFade.className}`}>
                        Information
                    </h1>
                </header>

                <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
                    <div ref={infoFade.ref} className={infoFade.className}>
                        <dl>
                            <InfoItem title="営業時間">
                                月～土 19:00～翌4:00 (L.O. 翌3:00)
                            </InfoItem>
                            <InfoItem title="定休日">
                                日曜日
                            </InfoItem>
                            <InfoItem title="電話番号">
                                <a href="tel:048-954-7970" className="hover:text-accent-primary transition-colors">048-954-7970</a>
                            </InfoItem>
                            <InfoItem title="ご予約">
                                お電話にて承ります。
                            </InfoItem>
                            <InfoItem title="お支払い">
                                クレジットカード (VISA, Master, JCB, AMEX, Diners), PayPay
                            </InfoItem>
                             <InfoItem title="喫煙">
                                全席喫煙可
                            </InfoItem>
                            <InfoItem title="アクセス">
                                埼玉県三郷市早稲田2-17-13 早稲田ビル1F
                                <br/>
                                JR武蔵野線 三郷駅北口 徒歩5分
                                <br/>
                                建物の真裏にコインパーキング有り
                            </InfoItem>
                        </dl>
                    </div>
                    <div ref={mapFade.ref} className={mapFade.className}>
                         <div className="aspect-w-16 aspect-h-9">
                           <iframe 
                             src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3235.9189917523177!2d139.88219501526218!3d35.80231648016624!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x601891f745501861%3A0xe5495832a26c48f!2z44CSMzQxLTAwMTgg5ZWG5YuL55yM5LiD6YOo5biC5pep56iy55S677yS5LiB55uu77yR77yX4oiS77yR77yT!5e0!3m2!1sja!2sjp!4v1684300000000!5m2!1sja!2sjp" 
                             width="100%" 
                             height="450" 
                             style={{ border: 0 }}
                             allowFullScreen={true}
                             loading="lazy"
                             referrerPolicy="no-referrer-when-downgrade"
                             title="Bar Eight Rabbit Location"
                             className="rounded-lg shadow-2xl"
                           ></iframe>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Info;

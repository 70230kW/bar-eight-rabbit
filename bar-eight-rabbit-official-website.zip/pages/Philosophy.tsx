
import React from 'react';
import { useScrollFadeIn } from '../hooks/useScrollFadeIn';

const TimelineItem: React.FC<{ year: string; title: string; description: string; align: 'left' | 'right' }> = ({ year, title, description, align }) => {
    const itemFade = useScrollFadeIn<HTMLDivElement>();
    const alignmentClass = align === 'left' ? 'lg:text-right lg:pr-8' : 'lg:text-left lg:pl-8';
    const orderClass = align === 'left' ? 'lg:order-1' : 'lg:order-3';

    return (
        <div ref={itemFade.ref} className={`mb-8 flex justify-between items-center w-full ${itemFade.className}`}>
            <div className={`hidden lg:block w-5/12 ${align === 'left' ? '' : 'order-3'}`}></div>
            <div className="z-10 flex items-center order-1 bg-accent-primary shadow-xl w-12 h-12 rounded-full">
                <h1 className="mx-auto font-semibold text-lg text-background-primary">{year}</h1>
            </div>
            <div className={`order-2 bg-background-secondary rounded-lg shadow-xl w-full lg:w-5/12 p-6 ${alignmentClass} ${orderClass}`}>
                <h3 className="font-bold text-text-primary text-xl font-serif">{title}</h3>
                <p className="text-sm leading-snug tracking-wide text-text-secondary mt-2">{description}</p>
            </div>
        </div>
    );
};

const Philosophy: React.FC = () => {
    const heroFade = useScrollFadeIn<HTMLDivElement>();
    const storyFade = useScrollFadeIn<HTMLDivElement>();

    return (
        <div className="bg-background-primary text-text-primary pt-24 md:pt-32">
            {/* Hero Section */}
            <header ref={heroFade.ref} className={`container mx-auto px-4 text-center ${heroFade.className}`}>
                <h1 className="font-serif text-[clamp(2.8rem,5.5vw,4.5rem)] text-accent-primary">バーテンダー、そして開拓者</h1>
                <p className="mt-4 max-w-3xl mx-auto text-text-secondary leading-[1.7]">
                    一杯のカクテルが人生を変えることがある。伊藤博之の物語は、その信念の証明です。
                </p>
            </header>

            {/* Story Section */}
            <section ref={storyFade.ref} className={`py-20 md:py-24 ${storyFade.className}`}>
                <div className="container mx-auto px-4">
                    <div className="grid lg:grid-cols-5 gap-12 items-center">
                        <div className="lg:col-span-2">
                             <img src="https://picsum.photos/800/1000?grayscale&random=5" alt="Hiroyuki Ito in action" className="rounded-lg shadow-2xl w-full h-full object-cover"/>
                        </div>
                        <div className="lg:col-span-3">
                            <h2 className="font-serif text-[clamp(2rem,4vw,3rem)] text-accent-primary">故郷への想い、グラスに込めて</h2>
                            <p className="mt-6 text-text-secondary leading-[1.7]">
                                バーテンダーとしてのキャリアは、都心の華やかな舞台から始まりました。しかし、心の奥底には常に故郷・三郷の風景がありました。「なぜ、自分の愛する街に、心から誇れるオーセンティックバーがないのだろう？」その問いが、すべての原動力となりました。
                            </p>
                            <p className="mt-4 text-text-secondary leading-[1.7]">
                                「BARの無い街にBARの文化を創る」—それは挑戦であり、開拓者としての使命でした。技術を磨き、知識を深め、そして2023年、カンパリグループ主催のカクテルコンペティションで日本一の栄光を手にしました。この称号は、私の哲学が間違っていなかったことの証です。Bar Eight Rabbitは、私の夢そのものです。
                            </p>
                        </div>
                    </div>
                </div>
            </section>
            
            {/* Timeline Section */}
            <section className="py-20 md:py-24 bg-background-secondary">
                 <div className="container mx-auto px-4 text-center">
                    <h2 className="font-serif text-[clamp(2rem,4vw,3rem)] text-accent-primary">The Journey</h2>
                </div>
                <div className="container mx-auto px-4 w-full h-full mt-12">
                    <div className="relative wrap overflow-hidden p-2 md:p-10 h-full">
                        <div className="border-2-2 absolute border-opacity-20 border-accent-primary h-full border" style={{left: '50%'}}></div>
                        <div className="hidden lg:block absolute border-opacity-20 border-accent-primary h-full border-2" style={{left: 'calc(50% - 1px)'}}></div>

                        <TimelineItem year="22歳" title="BARコンサルタントとして始動" description="都内のバーでキャリアをスタート。若干22歳でコンサルタントとして店舗の立ち上げや運営に携わり、業界のノウハウを学ぶ。" align="left"/>
                        <TimelineItem year="28歳" title="故郷・三郷で独立" description="長年の夢であった自身の店「Bar Eight Rabbit」をオープン。郊外でオーセンティックバーを成功させるという挑戦を開始する。" align="right"/>
                        <TimelineItem year="2023" title="日本チャンピオンへ" description="カンパリグループ主催のカクテルグランプリで見事優勝。その技術と創造性が全国に認められ、日本一のバーテンダーとなる。" align="left"/>
                        <TimelineItem year="現在" title="文化の創造" description="Bar Eight Rabbitを拠点に、三郷に新たなバー文化を根付かせるべく、日々カウンターに立ち続ける。" align="right"/>

                    </div>
                </div>
            </section>

        </div>
    );
};

export default Philosophy;


import React from 'react';
import { useScrollFadeIn } from '../hooks/useScrollFadeIn';

const MenuSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => {
    const sectionFade = useScrollFadeIn<HTMLDivElement>();
    return (
        <div ref={sectionFade.ref} className={`mb-16 ${sectionFade.className}`}>
            <h2 className="font-serif text-[clamp(2rem,4vw,3rem)] text-accent-primary border-b-2 border-accent-primary pb-4 mb-8 inline-block">{title}</h2>
            {children}
        </div>
    );
};

const Menu: React.FC = () => {
    const headerFade = useScrollFadeIn<HTMLHeadingElement>();

    return (
        <div className="bg-background-secondary text-text-primary pt-24 md:pt-32 pb-20 md:pb-32">
            <div className="container mx-auto px-4">
                <header className="text-center mb-20">
                    <h1 ref={headerFade.ref} className={`font-serif text-[clamp(2.8rem,5.5vw,4.5rem)] text-accent-primary ${headerFade.className}`}>
                        グラスの中の芸術
                    </h1>
                </header>
                
                <div className="max-w-4xl mx-auto">
                    <MenuSection title="Twist & Bespoke Cocktails">
                        <p className="text-text-secondary leading-[1.7]">
                            定番に独自の解釈を加えたツイストカクテル。そして、メニューにない一杯を。
                            <br />
                            あなたの好みを、ただお聞かせください。日本チャンピオンの技術と感性で、あなただけの特別なカクテルを創造します。
                        </p>
                         <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                            <img src="https://picsum.photos/600/800?random=11&grayscale" alt="Cocktail" className="rounded shadow-lg object-cover w-full h-80"/>
                            <img src="https://picsum.photos/600/800?random=12&grayscale" alt="Cocktail" className="rounded shadow-lg object-cover w-full h-80"/>
                            <img src="https://picsum.photos/600/800?random=13&grayscale" alt="Cocktail" className="rounded shadow-lg object-cover w-full h-80"/>
                        </div>
                    </MenuSection>

                    <MenuSection title="Spirits Selection">
                        <p className="text-text-secondary leading-[1.7]">
                            入手困難なジャパニーズウイスキーをはじめ、世界中から厳選した蒸留酒を取り揃えています。
                            その日の気分や好みに合わせて、最高の一杯をご提案いたします。
                        </p>
                        <div className="mt-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            <img src="https://picsum.photos/600/800?random=21&grayscale" alt="Whisky bottle" className="rounded shadow-lg object-cover w-full h-64"/>
                            <img src="https://picsum.photos/600/800?random=22&grayscale" alt="Whisky bottle" className="rounded shadow-lg object-cover w-full h-64"/>
                            <img src="https://picsum.photos/600/800?random=23&grayscale" alt="Whisky bottle" className="rounded shadow-lg object-cover w-full h-64"/>
                            <img src="https://picsum.photos/600/800?random=24&grayscale" alt="Whisky bottle" className="rounded shadow-lg object-cover w-full h-64"/>
                        </div>
                    </MenuSection>

                    <MenuSection title="Homemade Food">
                        <p className="text-text-secondary leading-[1.7]">
                            カクテルやウイスキーとのペアリングを考えた、自家製の軽食をご用意しております。
                        </p>
                    </MenuSection>

                    <MenuSection title="Price">
                        <p className="text-text-secondary text-lg">Charge: ¥500</p>
                        <p className="text-text-secondary text-lg">Service fee: 10%</p>
                    </MenuSection>
                </div>
            </div>
        </div>
    );
};

export default Menu;

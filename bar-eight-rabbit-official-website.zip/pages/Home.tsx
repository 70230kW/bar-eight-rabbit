
import React from 'react';
import { Link } from 'react-router-dom';
import { ScrollDownArrow } from '../components/Icons';
import { useScrollFadeIn } from '../hooks/useScrollFadeIn';

const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h2 className="font-serif text-[clamp(2rem,4vw,3rem)] text-accent-primary">{children}</h2>
);

const Home: React.FC = () => {
  const conceptSection = useScrollFadeIn<HTMLDivElement>();
  const bartenderSection = useScrollFadeIn<HTMLDivElement>();
  const cocktailsSection = useScrollFadeIn<HTMLDivElement>();

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center text-center text-white">
        <div className="absolute inset-0 bg-black opacity-50 z-10"></div>
        <img
          src="https://picsum.photos/1920/1080?grayscale&blur=1"
          alt="Bar Eight Rabbit counter"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 p-4">
          <h1 className="font-serif text-[clamp(2.8rem,5.5vw,4.5rem)] leading-tight drop-shadow-lg">
            ここは三郷ではない。
            <br />
            <span className="block mt-2">日本一のバーテンダーが創る、</span>
            <span className="block mt-2">一夜の隠れ家へ。</span>
          </h1>
        </div>
        <ScrollDownArrow />
      </section>

      {/* Concept Section */}
      <section ref={conceptSection.ref} className={`py-20 md:py-32 bg-background-primary ${conceptSection.className}`}>
        <div className="container mx-auto px-4 max-w-3xl text-center">
          <SectionTitle>三郷に、文化を創造する。</SectionTitle>
          <p className="mt-8 text-text-secondary text-[clamp(1rem,1.6vw,1.1rem)] leading-[1.7]">
            「三郷にいるとは思えない」— それは私たちが最も誇りに思う言葉です。
            Bar Eight Rabbitは、ただお酒を飲む場所ではありません。
            扉を開けた瞬間から始まる非日常的な体験。
            定番に独自の解釈を加えたツイストカクテル。
            静謐な空間で、グラスを傾け、自分と向き合う時間。
            私たちはこの街に、新しいバーの文化を創造します。
          </p>
        </div>
      </section>

      {/* The Bartender Section */}
      <section ref={bartenderSection.ref} className={`py-20 md:py-32 bg-background-secondary ${bartenderSection.className}`}>
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <SectionTitle>The Bartender</SectionTitle>
              <h3 className="mt-4 font-serif text-[clamp(1.5rem,3vw,2rem)] text-text-primary">伊藤 博之</h3>
              <p className="mt-2 text-accent-primary font-semibold tracking-wider">カンパリグループ・カクテルグランプリ2023 日本チャンピオン</p>
              <p className="mt-6 text-text-secondary leading-[1.7]">
                「BARの無い街にBARの文化を創ること」— それが私の哲学です。一杯のカクテルが、一杯のウイスキーが、人の心を豊かにし、街の景色を変える力を持っていると信じています。
              </p>
              <Link to="/philosophy" className="inline-block mt-8 bg-accent-primary text-background-primary font-bold py-3 px-8 hover:bg-opacity-80 transition-colors">
                PHILOSOPHY
              </Link>
            </div>
            <div>
              <img src="https://picsum.photos/800/1000?grayscale" alt="Bartender Hiroyuki Ito" className="rounded-lg shadow-2xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Our Cocktails & Spirits Section */}
      <section ref={cocktailsSection.ref} className={`py-20 md:py-32 bg-background-primary ${cocktailsSection.className}`}>
        <div className="container mx-auto px-4 text-center">
          <SectionTitle>Our Cocktails & Spirits</SectionTitle>
          <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
            <img src="https://picsum.photos/600/800?random=1&grayscale" alt="Signature Cocktail 1" className="aspect-[3/4] object-cover rounded shadow-lg" />
            <img src="https://picsum.photos/600/800?random=2&grayscale" alt="Signature Cocktail 2" className="aspect-[3/4] object-cover rounded shadow-lg" />
            <img src="https://picsum.photos/600/800?random=3&grayscale" alt="Rare Whisky Bottle" className="aspect-[3/4] object-cover rounded shadow-lg" />
            <img src="https://picsum.photos/600/800?random=4&grayscale" alt="Another rare bottle" className="aspect-[3/4] object-cover rounded shadow-lg" />
          </div>
          <Link to="/menu" className="inline-block mt-12 bg-accent-primary text-background-primary font-bold py-3 px-8 hover:bg-opacity-80 transition-colors">
            VIEW MENU
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;

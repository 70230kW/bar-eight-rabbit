
import React from 'react';
import { useScrollFadeIn } from '../hooks/useScrollFadeIn';

interface SpaceCardProps {
  imageSrc: string;
  altText: string;
  title: string;
  capacity: string;
  description: string;
  reverse?: boolean;
}

const SpaceCard: React.FC<SpaceCardProps> = ({ imageSrc, altText, title, capacity, description, reverse = false }) => {
    const cardFade = useScrollFadeIn<HTMLDivElement>();
    const imageOrder = reverse ? 'lg:order-last' : '';
    const textOrder = reverse ? 'lg:order-first' : '';

    return (
        <div ref={cardFade.ref} className={`grid lg:grid-cols-2 items-center gap-12 ${cardFade.className}`}>
            <div className={imageOrder}>
                <img src={imageSrc} alt={altText} className="rounded-lg shadow-2xl object-cover w-full h-[500px]" />
            </div>
            <div className={`text-center lg:text-left ${textOrder}`}>
                <h2 className="font-serif text-[clamp(2rem,4vw,3rem)] text-accent-primary">{title}</h2>
                <p className="mt-2 text-text-primary font-semibold">{capacity}</p>
                <p className="mt-6 text-text-secondary leading-[1.7]">
                    {description}
                </p>
            </div>
        </div>
    );
};


const Space: React.FC = () => {
    const headerFade = useScrollFadeIn<HTMLHeadingElement>();

    return (
        <div className="bg-background-primary text-text-primary pt-24 md:pt-32 pb-20 md:pb-32">
            <div className="container mx-auto px-4">
                <header className="text-center mb-20 md:mb-32">
                    <h1 ref={headerFade.ref} className={`font-serif text-[clamp(2.8rem,5.5vw,4.5rem)] text-accent-primary ${headerFade.className}`}>
                        日常を置き去る場所
                    </h1>
                </header>

                <div className="space-y-20 md:space-y-32">
                    <SpaceCard
                        imageSrc="https://picsum.photos/1200/800?random=31&grayscale"
                        altText="重厚なカウンター席"
                        title="カウンター席"
                        capacity="10席"
                        description="一枚板の重厚なカウンター。バーテンダーとの会話を愉しんだり、目の前で繰り広げられるカクテルメイキングを眺めたり。お一人様でも、大切な方と二人でも、特別な時間を過ごせます。"
                    />
                    <SpaceCard
                        imageSrc="https://picsum.photos/1200/800?random=32&grayscale"
                        altText="親密なテーブル席"
                        title="テーブル席"
                        capacity="3名様 × 2席"
                        description="親密な会話を楽しむのに最適なテーブル席。デートや記念日など、二人だけの世界に浸りたい夜にぴったりです。柔らかな照明が、心地よい雰囲気を演出します。"
                        reverse={true}
                    />
                    <SpaceCard
                        imageSrc="https://picsum.photos/1200/800?random=33&grayscale"
                        altText="寛ぎのソファ席"
                        title="ソファ席"
                        capacity="5名様 × 1席"
                        description="ゆったりと寛げるソファ席は、少人数のグループでのご利用に最適です。仲間と語り合いながら、希少なウイスキーを心ゆくまでお楽しみください。"
                    />
                </div>
            </div>
        </div>
    );
};

export default Space;

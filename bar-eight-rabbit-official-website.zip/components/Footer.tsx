
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-background-secondary text-text-secondary">
      <div className="container mx-auto py-8 px-4 text-center">
        <p className="font-serif text-lg text-text-primary mb-2">Bar Eight Rabbit</p>
        <p className="text-sm">埼玉県三郷市早稲田2-17-13 早稲田ビル1F</p>
        <p className="text-sm">TEL: 048-954-7970</p>
        <p className="mt-6 text-xs">&copy; {new Date().getFullYear()} Bar Eight Rabbit. All Rights Reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;

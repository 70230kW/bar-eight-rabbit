import React, { useState, useEffect, useRef } from 'react';
import { NAV_LINKS } from '../constants';
import { MenuIcon, CloseIcon } from './Icons';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const observer = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    const handleObserver = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    };

    observer.current = new IntersectionObserver(handleObserver, {
      rootMargin: '-50% 0px -50% 0px', // Activate when section is in the middle of the viewport
      threshold: 0,
    });
    
    const sections = NAV_LINKS.map(link => document.getElementById(link.id)).filter((el): el is HTMLElement => el !== null);
    sections.forEach((section) => {
      if(observer.current) observer.current.observe(section)
    });

    return () => {
        sections.forEach((section) => {
            if (observer.current) {
                observer.current.unobserve(section);
            }
        });
    };
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    setActiveSection(id);
    setIsOpen(false);

    const targetElement = document.getElementById(id);
    if (targetElement) {
      targetElement.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });
    }
  };

  return (
    <header className="fixed top-0 left-0 w-full z-50 text-text-primary p-4 md:p-6 lg:p-8 bg-background-primary/80 backdrop-blur-sm transition-colors duration-300">
      <div className="container mx-auto flex justify-between items-center">
        <a href="#home" onClick={(e) => handleNavClick(e, 'home')} className="font-serif text-[clamp(1.5rem,3vw,2rem)] text-accent-primary hover:opacity-80 transition-opacity">
          Bar Eight Rabbit
        </a>
        <nav className="hidden md:flex space-x-6 lg:space-x-8 items-center">
          {NAV_LINKS.map((link) => (
            <a
              key={link.name}
              href={link.path}
              onClick={(e) => handleNavClick(e, link.id)}
              className={`font-sans uppercase tracking-wider text-sm hover:text-accent-primary transition-colors ${
                  activeSection === link.id ? 'text-accent-primary' : 'text-text-primary'
              }`}
            >
              {link.name}
            </a>
          ))}
        </nav>
        <div className="md:hidden">
          <button onClick={() => setIsOpen(!isOpen)} aria-label="Open menu" aria-expanded={isOpen}>
            {isOpen ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>
      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 bg-background-primary/80 backdrop-blur-sm transition-opacity duration-300 md:hidden ${
          isOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
        onClick={() => setIsOpen(false)}
      >
        <div 
          className={`absolute inset-y-0 right-0 w-2/3 max-w-sm bg-background-secondary p-8 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
          onClick={(e) => e.stopPropagation()}
          role="dialog"
          aria-modal="true"
        >
          <div className="flex justify-end">
            <button onClick={() => setIsOpen(false)} className="mb-8" aria-label="Close menu">
              <CloseIcon />
            </button>
          </div>
          <nav className="flex flex-col space-y-8 mt-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.name}
                href={link.path}
                onClick={(e) => handleNavClick(e, link.id)}
                className={`font-serif text-2xl hover:text-accent-primary transition-colors ${
                  activeSection === link.id ? 'text-accent-primary' : 'text-text-primary'
                }`}
              >
                {link.name}
              </a>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
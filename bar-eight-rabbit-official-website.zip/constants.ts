export const NAV_LINKS = [
  { name: 'Home', path: '#home', id: 'home' },
  { name: 'Concept', path: '#concept', id: 'concept' },
  { name: 'Philosophy', path: '#philosophy', id: 'philosophy' },
  { name: 'Menu', path: '#menu', id: 'menu' },
  { name: 'Our Space', path: '#space', id: 'space' },
  { name: 'Information', path: '#info', id: 'info' },
];
